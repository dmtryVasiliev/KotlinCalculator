package com.example.calc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText
import java.lang.Math.abs

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun onClick(view: View?) {
        val inOutputRes: TextInputEditText = findViewById(R.id.inOutputResult)
        var text: String = inOutputRes.text.toString()
        val operView: TextView = findViewById(R.id.inputOper)
        val prevVal: TextView = findViewById(R.id.prevVal)
        var butVal: String = ""


        when (view?.id ?: return) {
            R.id.num0 -> {
                if (text != "0") butVal += "0"
            }

            R.id.num1 -> {
                if (text != "0") butVal += "1"
                else text = "1"
            }

            R.id.num2 -> {
                if (text != "0") butVal += "2"
                else text = "2"
            }

            R.id.num3 -> {
                if (text != "0") butVal += "3"
                else text = "3"
            }

            R.id.num4 -> {
                if (text != "0") butVal += "4"
                else text = "4"
            }

            R.id.num5 -> {
                if (text != "0") butVal += "5"
                else text = "5"
            }

            R.id.num6 -> {
                if (text != "0") butVal += "6"
                else text = "6"
            }

            R.id.num7 -> {
                if (text != "0") butVal += "7"
                else text = "7"
            }

            R.id.num8 -> {
                if (text != "0") butVal += "8"
                else text = "8"
            }

            R.id.num9 -> {
                if (text != "0") butVal += "9"
                else text = "9"
            }

            R.id.signDot -> {
                if (text == "") butVal += "0."
                else {
                    val isExist = "." in text
                    if (!isExist)
                        butVal += "."
                }
            }

            R.id.signPlus -> {
                if (operView.text == "") {// чтобы прошлое зн-е не менялось при измен-и опер-ции
                    prevVal.text = text
                    inOutputRes.setText("")
                }
                if (prevVal.text != "" || inOutputRes.toString() == "")  //чтобы без чисел не вывод-сь опер-ций
                    operView.text = "+"
            }

            R.id.signMinus -> {
                if (operView.text == "") {
                    prevVal.text = text
                    inOutputRes.setText("")
                }
                if (prevVal.text != "" || inOutputRes.toString() == "")
                    operView.text = "-"
            }

            R.id.signMulti -> {
                if (operView.text == "") {
                    prevVal.text = text
                    inOutputRes.setText("")
                }
                if (prevVal.text != "" || inOutputRes.toString() == "")
                    operView.text = "*"
            }

            R.id.signDiv -> {
                if (operView.text == "") {
                    prevVal.text = text
                    inOutputRes.setText("")
                }
                if (prevVal.text != "" || inOutputRes.toString() == "")
                    operView.text = "/"
            }
        }

        if (inOutputRes.text.toString() != "0") //чтобы 0 изменялся на 1...9
            text = inOutputRes.text.toString()
        inOutputRes.setText("$text$butVal")
    }


    fun clearOper(view: View?) {
        val inOutputResult: TextInputEditText = findViewById(R.id.inOutputResult)
        val prevValView: TextView = findViewById(R.id.prevVal)
        val operationView: TextView = findViewById(R.id.inputOper)
        prevValView.text = ""
        operationView.text = ""
        inOutputResult.setText("")

    }


    fun delLastOper(view: View?) {
        val inOutPutResult: TextInputEditText = findViewById(R.id.inOutputResult)
        if (inOutPutResult.text.toString() != "") {
            val str: String = inOutPutResult.text.toString().substring(0, inOutPutResult.length() - 1)
            inOutPutResult.setText(str)
            }
        }


    fun equalOper(view: View?) {
        val inOutputResult: TextInputEditText = findViewById(R.id.inOutputResult)
        val prevValView: TextView = findViewById(R.id.prevVal)
        val oper: TextView = findViewById(R.id.inputOper)
        val newNum: String = inOutputResult.text.toString()
        val prevNum: String = prevValView.text.toString()
        var result: Double = 0.0

        if (oper.text != "" && prevValView.text != "" && inOutputResult.text.toString() != "") {
            when (oper.text) {
                "+" -> result = prevNum.toDouble() + newNum.toDouble()
                "-" -> result = prevNum.toDouble() - newNum.toDouble()
                "*" -> result = prevNum.toDouble() * newNum.toDouble()
                "/" -> result = prevNum.toDouble() / newNum.toDouble()
            }

            if (abs(result - result.toInt()) > 0)
                inOutputResult.setText(result.toString())
            else {
                val res = result.toInt()
                inOutputResult.setText(res.toString())
            }
            prevValView.text = ""
            oper.text = ""
        }
    }
}